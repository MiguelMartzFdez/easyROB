"""Checks for the dedicated CheckML desktop entry point."""

import os
from types import SimpleNamespace

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtWidgets import QApplication, QTabWidget

from gui_easyrob.main.window import EasyROB
from gui_easyrob.bot.bot_context import build_gui_snapshot
from gui_easyrob.web_shell import WorkflowBridge
from gui_easyrob import checkml_launcher


def test_checkml_mode_limits_navigation_and_tutorial():
    app = QApplication.instance() or QApplication([])
    window = EasyROB(mode="checkml")
    try:
        assert window.windowTitle() == "CheckML"
        assert [window.tab_widget.tabText(index) for index in range(window.tab_widget.count())] == [
            "CheckML", "Results",
        ]
        assert window.tab_widget.currentWidget() is window.checkml_tab
        results_index = window.tab_widget.indexOf(window.results_workspace)
        assert not window.tab_widget.isTabEnabled(results_index)
        window.results_workspace.set_available("Report", True)
        assert window.tab_widget.isTabEnabled(results_index)
        assert window.tutorial_topics() == (("check_model", "Check ML"),)
        assert window.bot_panel.suggested_combo.count() == 2
        assert "CheckML" in window.bot_panel.subtitle_label.text()

        window.web_active_page = "Results"
        assert build_gui_snapshot(window).workflow == "CHECKML"
        window.web_active_page = "CheckML"

        window.show_tutorial_dialog()
        app.processEvents()
        tutorial_tabs = window.tutorial_dialog.findChildren(QTabWidget)
        assert len(tutorial_tabs) == 1
        assert tutorial_tabs[0].count() == 1
        assert tutorial_tabs[0].tabText(0) == "Check ML"

        bridge = WorkflowBridge(window)
        try:
            assert bridge.getTutorials().count('"id": "check_model"') == 1
            assert '"id": "overview"' not in bridge.getTutorials()
        finally:
            bridge._timer.stop()
    finally:
        window.close()


def test_easyrob_mode_keeps_existing_navigation():
    topics = EasyROB.tutorial_topics(SimpleNamespace(app_mode="easyrob"))
    assert ("check_model", "Check ML") in topics
    assert len(topics) > 1


def test_checkml_entry_selects_dedicated_mode(monkeypatch):
    modes = []
    monkeypatch.setattr(checkml_launcher, "launch_gui", lambda mode: modes.append(mode))
    checkml_launcher.main()
    assert modes == ["checkml"]
